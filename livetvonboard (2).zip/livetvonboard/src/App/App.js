import React from 'react';
import './App.css';
import SideMenu from "../Component/SideMenu";
import { makeStyles, CssBaseline, createMuiTheme, ThemeProvider } from '@material-ui/core';
import Header from "../Component/Header";
import PageHeader from '../Component/PageHeader';
import LiveTV from "../../src/pages/LiveTV/LiveTV";

const theme = createMuiTheme({
  palette: {
    primary: {
      main: "#333996",
      light: '#3c44b126'
    },
    secondary: {
      main: "#f83245",
      light: '#f8324526'
    },
    background: {
      default: "#f4f5fd"
      //default:"#b2ebf2"
    },
  },
  shape:{
    borderRadius:'12px'
  },
  overrides:{
    MuiAppBar:{
      root:{
        transform:'translateZ(0)'
      }
    }
  },
  props:{
    MuiIconButton:{
      disableRipple:true
    }
  }
})


const useStyles = makeStyles({
  appMain: {
    paddingLeft: '150px',
    width: '100%'
  }
})

function App() {
  const classes = useStyles();

  return (
    <ThemeProvider theme={theme}>
    <SideMenu/>
    <div className={classes.appMain}>
     <Header/>
     <PageHeader
     title="LiveTV Onboarding"
     subTitle="JIO POS"
     />
     <LiveTV/>
     <CssBaseline />
    </div>
    </ThemeProvider>
  );
}

export default App;
