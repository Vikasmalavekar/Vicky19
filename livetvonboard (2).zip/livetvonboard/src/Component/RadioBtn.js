import React from "react";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";

export default function FormControlLabelPlacement() {
  return (
    <FormControl component="fieldset" >
      {/* <FormLabel component="legend">labelPlacement</FormLabel> */}
      <RadioGroup row aria-label="position" name="position" defaultValue="">
        <FormControlLabel
          value="YES"
          control={<Radio color="primary" />}
          label="Yes"
          labelPlacement="start"
        />
        <FormControlLabel
          value="NO"
          control={<Radio color="secondary" />}
          label="No"
          labelPlacement="start"
        />
      </RadioGroup>
    </FormControl>
  );
}
