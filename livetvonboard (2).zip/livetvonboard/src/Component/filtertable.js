import React from "react";
import { Grid } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import FormControl from "@material-ui/core/FormControl";
import RadioBtn from "./RadioBtn";

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 150,
  },
  container: {
    display: "grid",
    gridTemplateColumns: "repeat(12, 1fr)",
    gridGap: theme.spacing(1),
  },
  paper: {
    margin: theme.spacing(3),
    padding: theme.spacing(3),
    // padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary,
    whiteSpace: "nowrap",
    // marginBottom: theme.spacing(1),
  },
  root: {
    flexGrow: 1,
  },
  table: {
    minWidth: 600,
  }
}));

function createData(r4gstate, pincode, action) {
  return { r4gstate, pincode, action };
}

const rows = [createData("MAHARASHTRA", 400701, "YES/NO")];

export default function BasicTable() {
  const classes = useStyles();

  return (
    <form>
    {/* <Grid container> */}
      <Grid item xs={8}>
      <Paper className={classes.paper}>
          <FormControl className={classes.formControl}>
          <TableContainer component={Paper}>
            <Table className={classes.table} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell align="center">R4G STATE</TableCell>
                  <TableCell align="center">PINCODE</TableCell>
                  <TableCell align="center">Live TV Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row) => (
                  <TableRow key={row.name}>
                    <TableCell component="th" scope="row" align="center">
                      {row.r4gstate}
                    </TableCell>
                    <TableCell align="center">{row.pincode}</TableCell>
                    {/* <TableCell align="center">{row.action}</TableCell> */}
                    <TableCell align="center">
                        <RadioBtn/>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          </FormControl>
        </Paper>
      </Grid>
    {/* </Grid> */}
  </form>
  );
}
