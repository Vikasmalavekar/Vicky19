import { Paper } from "@material-ui/core";
import react from "react";
import { makeStyles } from "@material-ui/core/styles";
import LiveTVform from "./LiveTVform";
import Table from "../../Component/filtertable";


export default function LiveTV() {
 
  return (
    <>
      {/* <Paper className={classes.pageContemt}> */}
        <LiveTVform />
      {/* </Paper> */}

        <Table />
     
    </>
  );
}
